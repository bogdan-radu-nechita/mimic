package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DataSender {


    @Autowired
    private SimpMessagingTemplate webSocket;

    public void sendDataToGUI(Sensor sensor, SensorRecord linAcceleration){
        try{

            List<SensorRecord> data = new ArrayList<>();
            data.add(linAcceleration);

            String topic = "";

            switch (sensor) {
                case GYROSCOPE:             topic = "/topic/messages/gyroscope"; break;
                case LINEAR_ACCELERATION:   topic = "/topic/messages/acceleration"; break;
                case ACCELEROMETER:         topic = "/topic/messages/linAcceleration"; break;
            }

            webSocket.convertAndSend(topic, data);

        }catch (Exception e){
            System.out.println("Failed to send " + sensor.getName());
            e.printStackTrace();
        }
    }

    public void sendDataToGUITEST(SensorRecord rec, Sensor sensor){

        String path ="";

        switch (sensor){
            case GYROSCOPE:           path = "/topic/test/normal"; break;
            case LINEAR_ACCELERATION: path = "/topic/test/transformed";  break;
            //case ACCELEROMETER       : path = "/topic/messages/acceleration";  break;
        }

        try{
            List<SensorRecord> data = new ArrayList<>();
            data.add(rec);
            webSocket.convertAndSend(path, data);
        }catch (Exception e){
            System.out.println("Failed to send gyro...");
            e.printStackTrace();
        }
    }
}
