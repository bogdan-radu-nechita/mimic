package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SensorDataService2 {

    public static final int GYROSCOPE = 1;
    public static final int LINEAR_ACCELEROMETER = 2;
    public static final int ACCELEROMETER = 3;

    @Autowired
    DataTransformationService dataTransformationService;

    @Autowired
    DataAnalysisService dataAnalysisService;

    @Autowired
    DataSender ds;

    private static Integer nrOf0s = 0;

    @Autowired
    private SimpMessagingTemplate webSocket;

    public void handleNewData(SensorRecord sr, Gesture g, Sensor sensor){
        SensorRecord newSr = dataTransformationService.transformNewRecord(g.getSensors().get(sensor.getId()-1), sr);
        int numberOf0s_old = RecordHolder.numberOf0sG;
        int currentIndex = 0;

        switch (sensor){
            case GYROSCOPE           :
                if(newSr.getX() == 0 && newSr.getY()==0 && newSr.getZ()==0) {
                    RecordHolder.numberOf0sG++;
                }
                try{
                    RecordHolder.gyroscopeData.add(sr); RecordHolder.transfGyroscopeData.add(newSr);
                } catch(Exception e){e.printStackTrace();}

                break;
            case LINEAR_ACCELERATION: try{RecordHolder.linData.add(sr); RecordHolder.transfLinData.add(newSr);} catch(Exception e){e.printStackTrace();}  break;
            case ACCELEROMETER       : try{RecordHolder.accData.add(sr); RecordHolder.transfAccData.add(newSr);} catch(Exception e){e.printStackTrace();}  break;
        }

        currentIndex = RecordHolder.gyroscopeData.size()-1;
        DataAnalysisService.checkSignalForGestures(numberOf0s_old, currentIndex);

        ds.sendDataToGUITEST(sr, Sensor.GYROSCOPE);
        ds.sendDataToGUITEST(newSr, Sensor.LINEAR_ACCELERATION);

/*        System.out.println(nrOf0s);
        int prevNrOf0s = nrOf0s;

        nrOf0s += checkIfGesture(g, sensor, sr);
        if(nrOf0s != prevNrOf0s){

        }*/
    }



}
