package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.SensorRecord;

import java.util.ArrayList;
import java.util.List;

public class RecordHolder {
    public static List<SensorRecord> gyroscopeData = new ArrayList<>();
    public static List<SensorRecord> transfGyroscopeData = new ArrayList<>();
    public static int numberOf0sG = 0;


    public static List<SensorRecord> linData = new ArrayList<>();
    public static List<SensorRecord> transfLinData = new ArrayList<>();

    public static List<SensorRecord> accData = new ArrayList<>();
    public static List<SensorRecord> transfAccData = new ArrayList<>();


}
