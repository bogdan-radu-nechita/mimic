package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.SensorParam;
import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.training.DataTransformer;
import ino.bogdan.datastuf.alg.training.fileLoading.FileManager;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DataTransformationService {

    public void transformTestFile(Gesture g){
        List<List<SensorRecord>> data = FileManager.readTestFile();

        List<List<SensorRecord>> result = DataTransformer.transforTestFile(data, g);
    }

    public SensorRecord transformNewRecord(SensorParam param, SensorRecord data){
        return DataTransformer.transformRecordData(param, data);
    }
}
