package ino.bogdan.datastuf.alg.model.sensor;

import java.util.HashMap;
import java.util.Map;

public class AxisInfluencePercentage {
    int axisId;
    HashMap<String, Double> signPercentages;
    Double dominantPercentage;
    String dominantSign;

    public AxisInfluencePercentage(int axisId){
        this.axisId = axisId;

        this.signPercentages = new HashMap<>();

        dominantPercentage = null;
        dominantSign = null;
    }

    public AxisInfluencePercentage(int axisId, HashMap<String, Double> signPercentages){
        this.axisId = axisId;

        this.signPercentages.putAll(signPercentages);

        dominantPercentage = null;
        dominantSign = null;
    }

    public void setAxisSignPecentages(HashMap<String, Double> signPercentages){
        this.signPercentages.putAll(signPercentages);
    }

    public Double getDominantPercentage() {
        if(dominantPercentage != null)
            return dominantPercentage;

        getShortestDominantSign();

        return dominantPercentage;
    }

    public String getDominantSign() {
        if(dominantSign != null)
            return dominantSign;

        getShortestDominantSign();

        return dominantSign;
    }

    public HashMap<String, Double> getSignPercentages(){
        return this.signPercentages;
    }

    public int getAxisId(){
        return this.axisId;
    }

    private void getShortestDominantSign(){
        String shortestSign ="";
        Double maxPercentage = 0.0;

        for(Map.Entry<String, Double> e : signPercentages.entrySet()){
            shortestSign = e.getKey();
            maxPercentage = e.getValue();
            break;
        }

        for(Map.Entry<String, Double> e : signPercentages.entrySet()){

            if(e.getKey().length() < shortestSign.length()){
                if(e.getKey().length() == 1){
                    maxPercentage += e.getValue();
                }else{
                    if(shortestSign.contains(e.getKey())){
                        maxPercentage += e.getValue();
                        shortestSign   = e.getKey();
                    }else{
                        if(e.getValue() > maxPercentage){
                            maxPercentage = e.getValue();
                            shortestSign  = e.getKey();
                        }
                    }
                }
            }

            if(e.getKey().length() == shortestSign.length()){
                if(e.getValue() > maxPercentage){
                    maxPercentage = e.getValue();
                    shortestSign  = e.getKey();
                }
            }

            if(e.getKey().length() > shortestSign.length()){
                if(e.getKey().contains(shortestSign)){
                    maxPercentage += e.getValue();
                }
/*                else{
                    if(e.getValue() > maxPercentage){
                        maxPercentage = e.getValue();
                        shortestSign  = e.getKey();
                    }
                }*/
            }
        }

        dominantPercentage = maxPercentage;
        dominantSign = shortestSign;

    }
}
