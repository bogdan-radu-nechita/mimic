package ino.bogdan.datastuf.model.infoholders;

public enum Sensor {
    GYROSCOPE(1,"gyro", "/gyroscope","gyro_"),  LINEAR_ACCELERATION(2,"linAcc" ,"/lin_accelerometer","lin_acc_"), ACCELEROMETER(3, "acc", "/accelerometer","acc_");

    private int id;
    private String name;
    private String folder;
    private String filePrefix;

    Sensor(int id, String name, String folder, String filePrefix){
        this.id = id;
        this.name = name;
        this.folder = folder;
        this.filePrefix = filePrefix;
    }

    public int getId(){
        return this.id;
    }

    public String getName(){
        return this.name;
    }

    public String getFolder(){
        return this.folder;
    }

    public String getFilePrefix(){
        return this.filePrefix;
    }

    public static Sensor getSensorById(int id) {
        for(Sensor s : Sensor.values()) {
            if (s.getId() == id){
                return s;
            }
        }

        return null;
    }
}
