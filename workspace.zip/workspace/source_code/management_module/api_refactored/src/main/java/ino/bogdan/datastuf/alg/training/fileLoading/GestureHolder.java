package ino.bogdan.datastuf.alg.training.fileLoading;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.training.GestureTrainer;
import ino.bogdan.datastuf.alg.utils.Constants;

import java.util.HashMap;
import java.util.Map;

public class GestureHolder {
    public static HashMap<Integer, Gesture> gestures;

    private static void initGestures(){
        gestures = new HashMap<>();

        gestures.put(1, new Gesture("open", Constants.UNKNOWN));
        gestures.put(2, new Gesture("slap", Constants.FORWARD));
        gestures.put(3, new Gesture("grab", Constants.FORWARD));
        gestures.put(4, new Gesture("snap_fingers", Constants.FORWARD));
    }

    public static HashMap<Integer, Gesture> getGestures(){
        if(gestures == null){


            /**
             * Load from file or db
             * Right now it's hardcoded
             */
            initGestures();


            /**
             * Check if trained or not
             */

            for(Map.Entry<Integer, Gesture> entry : gestures.entrySet()){
                if(entry.getValue().getTrained() == 0){
                    GestureTrainer trainer = new GestureTrainer(entry.getValue());
                    trainer.train();

                    //entry.getValue().getSensors().
                }
            }



        }

        return gestures;
    }

    public static Gesture getGestureById(int id){
        if(gestures == null){
            initGestures();
        }

        if(gestures.get(id).getTrained() == 0){
            GestureTrainer trainer = new GestureTrainer(gestures.get(id));
            trainer.train();
        }

        return gestures.get(id);
    }

    public static Gesture getGestureByName(String name){

        if(gestures == null){
            initGestures();
        }

        Gesture g = null;

        for(Map.Entry<Integer, Gesture> entry : gestures.entrySet()){
            if(entry.getValue().getName().equals(name)){
                g = entry.getValue();
            }
        }

        if(g.getTrained() == 0){
            GestureTrainer trainer = new GestureTrainer(g);
            trainer.train();
        }

        return g;
    }
}
