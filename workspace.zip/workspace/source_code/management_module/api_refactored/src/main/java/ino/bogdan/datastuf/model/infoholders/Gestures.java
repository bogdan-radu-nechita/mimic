package ino.bogdan.datastuf.model.infoholders;

public enum Gestures {

    OPEN(1,"/open"), SLAP(2,"/slap"), POINT(3,"/point"), GRAB(4,"/grab"), NEXT(5, "/next"), RUB_FINGERS(6, "/rub_fingers"), SNAP_FINGERS(7, "/snap_fingers"), PREVIOUS(8, "/previous");

    private int id;
    private String folder;

    Gestures(int id, String folder){
        this.id = id;
        this.folder = folder;
    }

    public int getId(){
        return this.id;
    }

    public String getFolder(){
        return this.folder;
    }
}
