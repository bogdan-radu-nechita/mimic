package ino.bogdan.datastuf.controller;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.training.fileLoading.GestureHolder;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import ino.bogdan.datastuf.service.SensorDataService2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class WebSocketController {

    @Autowired
    SensorDataService2 sensorDataService;

    @MessageMapping("/dataRecorder/recordGyro")
    @SendTo("/topic/recordGyro")
    public void recordGyro(@Payload String payload) throws Exception {
        String[] sensorRecord = parseSensorWSPayload(payload);
        //System.out.println("The parsed payload: - " + Arrays.toString(sensorRecord));
        sensorDataService.handleNewData(new SensorRecord(
                        sensorRecord[0],
                        sensorRecord[1],
                        sensorRecord[2],
                        sensorRecord[3]
                ),
                GestureHolder.getGestureByName("open"),
                Sensor.GYROSCOPE);
    }

    @MessageMapping("/dataRecorder/recordLinAcc")
    @SendTo("/topic/recordLinAcc")
    public void recordLinAcc(@Payload String payload) throws Exception {
        String[] sensorRecord = parseSensorWSPayload(payload);
        sensorDataService.handleNewData(new SensorRecord(
                        sensorRecord[0],
                        sensorRecord[1],
                        sensorRecord[2],
                        sensorRecord[3]
                ),
                GestureHolder.getGestureByName("open"),
                Sensor.LINEAR_ACCELERATION);
    }

    @MessageMapping("/dataRecorder/recordAcc")
    @SendTo("/topic/recordAcc")
    public void recordAcc(@Payload String payload) throws Exception {
        String[] sensorRecord = parseSensorWSPayload(payload);
        sensorDataService.handleNewData(new SensorRecord(
                        sensorRecord[0],
                        sensorRecord[1],
                        sensorRecord[2],
                        sensorRecord[3]
                ),
                GestureHolder.getGestureByName("open"),
                Sensor.ACCELEROMETER);
    }

    private String[] parseSensorWSPayload(String payload){
        String[] result = new String[4];
        String[] payloadFields = StringUtils.tokenizeToStringArray(payload, ",");

        result[0] = StringUtils.tokenizeToStringArray(payloadFields[0], ":")[1]; //timestamp
        result[1] = StringUtils.tokenizeToStringArray(payloadFields[1], ":")[1]; //x
        result[2] = StringUtils.tokenizeToStringArray(payloadFields[2], ":")[1]; //y
        result[3] = StringUtils.tokenizeToStringArray(payloadFields[3], ":")[1]; //z
        result[3] = StringUtils.tokenizeToStringArray( result[3], "}")[0];

        return result;
    }




    /**
     * ................................................................................................................................
     */


    @MessageMapping("/chat/g")
    @SendTo("/topic/messages/gyroscope")
    public List<SensorRecord> sendG(Message message) throws Exception {
        //System.out.println("Called WebSocket");
        //return sensorDataService.retrieveGyroscopeData();
        return null;
    }

    @MessageMapping("/chat/la")
    @SendTo("/topic/messages/linacceleration")
    public List<SensorRecord> sendLA(Message message) throws Exception {
        //System.out.println("Called WebSocket");
        //return sensorDataService.retrieveGyroscopeData();
        return null;
    }

    @MessageMapping("/chat/a")
    @SendTo("/topic/messages/acceleration")
    public List<SensorRecord> sendA(Message message) throws Exception {
        //System.out.println("Called WebSocket");
        //return sensorDataService.retrieveGyroscopeData();
        return null;
    }

    @MessageMapping("/chat/TEST/normal")
    @SendTo("/topic/test/normal")
    public List<SensorRecord> testNormal(Message message) throws Exception {
        //System.out.println("Called WebSocket");
        //return sensorDataService.retrieveGyroscopeData();
        return null;
    }

    @MessageMapping("/chat/TEST/transformed")
    @SendTo("/topic/test/transformed")
    public List<SensorRecord> testTransformed(Message message) throws Exception {
        //System.out.println("Called WebSocket");
        //return sensorDataService.retrieveGyroscopeData();
        return null;
    }
}
