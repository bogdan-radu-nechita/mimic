package ino.bogdan.datastuf.alg.training.fileLoading;


import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataReader {

    // TODO: maybe use Sensor instead of Integer
    public HashMap<Integer, List<List<SensorRecord>>>  allTrainingData;

    public DataReader(String gesture){

        System.out.println("[DataReader] Initializing with gesture: " + gesture);
        allTrainingData = new HashMap<>();

        allTrainingData.put(Sensor.GYROSCOPE.getId(), new ArrayList<>());
        allTrainingData.put(Sensor.LINEAR_ACCELERATION.getId(), new ArrayList<>());
        allTrainingData.put(Sensor.ACCELEROMETER.getId(), new ArrayList<>());

        for(Sensor sensor : Sensor.values()){
            System.out.println("[DataReader] Reading " + sensor.getName() + " sensor data...");
            List<List<String>> data = FileManager.readListOfFiles(gesture, sensor);
            System.out.println("[DataReader] Reading of " + sensor.getName() + " data successful! Creating objects...");
            int fileNo = 0;
            for(List<String> file : data){
                fileNo++;
                List<SensorRecord> sr = new ArrayList<>();
                int lineNo = 0;
                for(String s : file){
                    lineNo++;

                    if(s != ""){
                        String[] record = parseLine(s);

                        try {sr.add(new SensorRecord(record));  } catch (Exception e) {System.out.println("Looking for the null row... " + gesture + " : " + sensor.getName() + " : " + fileNo + " : " + lineNo + " :: " + record.length + " :: " + s + " :: " + s.length() + " :: " + (s == null));} //caused by empty rows in in a file
                    }

                }
                allTrainingData.get(sensor.getId()).add(sr);
            }

            System.out.println("[DataReader] Total data read for " + sensor.getName() + ": " + getTotalReadData(sensor.getId()));
        }

    }

    public String[] parseLine(String line){
        return StringUtils.tokenizeToStringArray(line, ",");
    }

    public HashMap<Integer, List<List<SensorRecord>>> getAllTrainingData(){
        return this.allTrainingData;
    }

    public int getTotalReadData(int sensorId){
        int sum = 0;

        for(int i=0; i< allTrainingData.get(sensorId).size(); i++){
            sum += allTrainingData.get((sensorId)).get(i).size();
        }

        return sum;
    }



}
