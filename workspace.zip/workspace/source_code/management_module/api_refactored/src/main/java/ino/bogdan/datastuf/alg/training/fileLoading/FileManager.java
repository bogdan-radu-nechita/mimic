package ino.bogdan.datastuf.alg.training.fileLoading;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.util.StringUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

    private static ClassLoader classLoader = FileManager.class.getClassLoader();

    public static List<List<String>> readListOfFiles(String gesture, Sensor sensor){

        String path = Constants.TRAINING_DATA_DIR + "/" + gesture + sensor.getFolder();
        System.out.println("[FileManager] Path to file: " + path);
        List<List<String>> lines = new ArrayList<>();

        String line;
        BufferedReader in;

        System.out.println("Testin..... " + path);
        System.out.println("Testin..... " + classLoader.getResource(path));

        File folder = new File(classLoader.getResource(path).getFile());



        File[] listOfFiles = folder.listFiles();

        for(int i = 0; i< listOfFiles.length; i++){
            lines.add(new ArrayList<>());
            try {
                in = new BufferedReader(new FileReader(listOfFiles[i]));
                while((line = in.readLine()) != null){

                    lines.get(i).add(line);

                }
                in.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            } catch (ArrayIndexOutOfBoundsException e){
                e.printStackTrace();
            }
        }

        return lines;
    }

    /**
     * Read test data
     */
    public static List<List<SensorRecord>> readTestFile(){
        String path = "C:\\licenta\\test_data";

        List<List<SensorRecord>> result = new ArrayList<>();
        List<SensorRecord> valuesG = readSensor(path + "\\gyroscope\\gyro_1.txt");
        List<SensorRecord> valuesL = readSensor(path + "\\lin_accelerometer\\lin_acc_1.txt");
        List<SensorRecord> valuesA = readSensor(path + "\\accelerometer\\acc_1.txt");

        result.add(valuesG);
        result.add(valuesL);
        result.add(valuesA);

        return result;

    }

    public static List<SensorRecord> readSensor(String path){
        List<SensorRecord> val = new ArrayList<>();

        File folder = new File(classLoader.getResource(path).getFile());
        File[] listOfFiles = folder.listFiles();

        String line;
        BufferedReader in = null;

        for(int i = 0; i< listOfFiles.length; i++){
            try {
                in = new BufferedReader(new FileReader(listOfFiles[i]));
                while((line = in.readLine()) != null){

                    String[] lineData = parseLine(line);
                    val.add(new SensorRecord(lineData));

                }
                in.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            } catch (ArrayIndexOutOfBoundsException e){
                e.printStackTrace();
            }
        }

        return val;
    }

    public static String[] parseLine(String line){
        return StringUtils.tokenizeToStringArray(line, ",");
    }
}
