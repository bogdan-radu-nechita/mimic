package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.configuration.AppStats;
import ino.bogdan.datastuf.configuration.Datasets;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

@Service
public class SensorDataService {

    private List<SensorRecord> gyroData;
    private List<SensorRecord> linAccData;
    private List<SensorRecord> accData;

    @Autowired
    Datasets datasets;

    @Autowired
    FileHandler fileHandlerl;

    @Autowired
    DataSender ds;

    @Autowired
    private SimpMessagingTemplate webSocket;

    private static int fileIndex;

    public void clearData(){
        gyroData = new ArrayList<>();
        linAccData = new ArrayList<>();
        accData = new ArrayList<>();
    }

    /**
     * Direct communication with the watch
     */
    public void handleNewData(Sensor sensor, SensorRecord newData){
        ds.sendDataToGUI(sensor, newData);
        appendToFile(sensor, newData);
    }


    private void ensureDataHoldersInitialization(){
        if(gyroData == null){
            gyroData = new ArrayList<>();
        }

        if(linAccData == null){
            linAccData = new ArrayList<>();
        }

        if(accData == null){
            accData = new ArrayList<>();
        }
    }

    private void appendToFile(Sensor sensor, SensorRecord newData){
        ensureDataHoldersInitialization();

        try{
        switch (sensor) {
            case GYROSCOPE: gyroData.add(newData); break;
            case LINEAR_ACCELERATION: linAccData.add(newData); break;
            case ACCELEROMETER: accData.add(newData); break;
        }

        } catch (Exception e){
            e.printStackTrace();
        }
        //System.out.println("New Gyro data -> " + gyroscope.getX() );
        //C:\licenta\training_data
    }

    /**
     * File managed part
     * @return
     */
    public HashMap<Integer, HashMap> retrieveAllData(){
        return fileHandlerl.loadData();
    }



    public void saveToFile(){
        System.out.println("GESTURE ----> " + AppStats.gesture.getFolder());

        for(Sensor sensor : Sensor.values()) {
            saveSensorToFile(sensor);
        }

        System.out.println("Save to file request served");
    }

    private void saveSensorToFile(Sensor sensor){
        long numberOfFiles = 0;

        // TODO: use try-with-resource
        try (Stream<Path> paths = Files.walk(Paths.get(Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()))) {
            numberOfFiles = paths.count() - 1; //paths.count returns 1 if there are no files present
        }catch(IOException e){
            e.printStackTrace();
        }

        StringBuilder sb = new StringBuilder();
        switch(sensor){
            case GYROSCOPE:
                System.out.println("Gyro data size to write: " + gyroData.size());
                for(SensorRecord g: gyroData){
                    try{sb.append(g.toString());} catch(NullPointerException e){System.out.println("am dat peste npe g");}
                    sb.append("\n");
                }
                break;

            case LINEAR_ACCELERATION:
                System.out.println("Lin data size to write: " + linAccData.size());
                for(SensorRecord la: linAccData){
                    try{sb.append(la.toString());} catch(NullPointerException e){System.out.println("am dat peste npe la");}
                    sb.append("\n");
                }
                break;

            case ACCELEROMETER:
                System.out.println("ACC data size to write: " + accData.size());
                for(SensorRecord a: accData){
                    try{sb.append(a.toString());} catch(NullPointerException e){System.out.println("am dat peste npe acc");}
                    sb.append("\n");
                }
                break;
        }

        String fileName = sensor.getFilePrefix() + ++numberOfFiles + Constants.FILE_TYPE;

        FileOutputStream out = null;
        try {

            out = new FileOutputStream(Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder() + "\\" + fileName);
            out.write(sb.toString().getBytes());
            out.close();

        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}










/*public List<Gyroscope> retrieveGyroscopeData(){
        return readGyroscopeFile("");
    }

    private List<Gyroscope> readGyroscopeFile(String fileName){
        String str;
        List<Gyroscope> result = new ArrayList<>();
        BufferedReader in = null;

        try{
            in = new BufferedReader(new FileReader(datasets.getDatasetsDirectory() + "\\s3_data_1.json"));
            StringBuilder sb = new StringBuilder();

            str = in.readLine();
            sb.append(str);

            while((str = in.readLine()) != null){
                sb.append(str);
            }

            str = sb.toString();
            String[] ceva = StringUtils.tokenizeToStringArray(str, ",");

            for(String s : ceva){
                String[] data = StringUtils.tokenizeToStringArray(s, "#");

                result.add(new Gyroscope(data[0],data[1],data[2],data[3]));
            }

        }catch (FileNotFoundException e){
            e.printStackTrace();
            //return "nu merge - nu gaseste fisierul";
        }catch (IOException e){
            e.printStackTrace();
            //return "nu merge - nu poate citi";
        }finally {
           try{
               if(in!=null){
                   in.close();
               }
           }catch (IOException e){
               e.printStackTrace();
           }
        }

        return result;
    }*/
