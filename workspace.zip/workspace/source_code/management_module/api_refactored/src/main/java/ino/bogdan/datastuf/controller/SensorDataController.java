package ino.bogdan.datastuf.controller;

import com.fasterxml.jackson.annotation.JsonFormat;
import ino.bogdan.datastuf.configuration.AppStats;
import ino.bogdan.datastuf.model.infoholders.Gestures;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import ino.bogdan.datastuf.service.FileHandler;
import ino.bogdan.datastuf.service.SensorDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@JsonFormat(shape= JsonFormat.Shape.ARRAY)
@RestController
public class SensorDataController {

    @Autowired
    SensorDataService sensorDataService;

    @Autowired
    AppStats appStats;

    @Autowired
    FileHandler fileHandler;

    @RequestMapping("/allData")
    public HashMap<Integer, HashMap> getAllData() {
        System.out.println("Called HTTP");
        return sensorDataService.retrieveAllData();
    }

    @RequestMapping("/save")
    public String save() {
        System.out.println("Called HTTP");
        sensorDataService.saveToFile();
        sensorDataService.clearData();

/*        if(AppStats.firstTime == true){
            AppStats.files = fileHandler.getFileNumber();
            AppStats.firstTime = false;
        }
        AppStats.files++;

        System.out.println("Current number of files: " + AppStats.files);*/
        return "yes";
    }

    @RequestMapping("/delete/{type}")
    public void deleteLastFile(@PathVariable("type") Integer type){

        fileHandler.deleteLastFile();
/*        if(AppStats.firstTime == true){
            AppStats.files = 1;
        }

        if(AppStats.files > 0){
            AppStats.files--;
        }

        System.out.println("Current number of files: " + AppStats.files);*/
    }

    @RequestMapping("/deleteLastTrimmed")
    public void deleteLastTrimmedFile(){

        fileHandler.deleteLastTrimmedFile();
/*        if(AppStats.firstTime == true){
            AppStats.files = 1;
        }

        if(AppStats.files > 0){
            AppStats.files--;
        }

        System.out.println("Current number of files: " + AppStats.files);*/
    }

    @RequestMapping("/gesture/status")
    public Integer getGestureStatus() {

        return AppStats.gesture.getId();
    }

    @RequestMapping(value = "/gesture/{id}", method = RequestMethod.POST)
    public void getGestureStatus(@PathVariable("id") Integer id) {

        switch (id) {
            case 1: //OPEN
                AppStats.gesture = Gestures.OPEN;
                break;
            case 2:
                AppStats.gesture = Gestures.SLAP;
                break;
            case 3:
                AppStats.gesture = Gestures.POINT;
                break;
            case 4:
                AppStats.gesture = Gestures.GRAB;
                break;
            case 5:
                AppStats.gesture = Gestures.NEXT;
                break;
            case 6:
                AppStats.gesture = Gestures.RUB_FINGERS;
                break;
            case 7:
                AppStats.gesture = Gestures.SNAP_FINGERS;
                break;
            case 8:
                AppStats.gesture = Gestures.PREVIOUS;
                break;
        }
        AppStats.files = 0;
    }

    @RequestMapping(value = "/gesture/range/{range}", method = RequestMethod.POST)
    public void correctDataSetToGesture(@PathVariable("range") String range) {

        String[] minMax = StringUtils.tokenizeToStringArray(range,">");

        System.out.println(range+ " " + minMax[0] + " " + minMax[1] + " " + minMax[2]);
        String[] minVal = StringUtils.tokenizeToStringArray(minMax[1],".");
        String[] maxVal = StringUtils.tokenizeToStringArray(minMax[2],".");

        int gestureId = Integer.parseInt(minMax[3]);

        fileHandler.reduceSensorDataSetToGesture(Sensor.getSensorById(gestureId), Integer.parseInt(minMax[0]), Long.parseLong(minVal[0]),Long.parseLong(maxVal[0])+1);
    }

    @RequestMapping(value = "/fileList", method = RequestMethod.GET)
    public Integer getFileList() {

        //AppStats.files = fileHandler.getFileNumber();

        return fileHandler.getFileNumber();
    }

    @RequestMapping(value = "/file/{id}", method = RequestMethod.GET)
    public HashMap<Integer, List> getFileList(@PathVariable("id") Integer id) {

        return fileHandler.getFileByNumber(id);
    }
}