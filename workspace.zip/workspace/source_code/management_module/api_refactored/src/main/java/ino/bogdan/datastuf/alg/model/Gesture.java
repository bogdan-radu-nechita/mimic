package ino.bogdan.datastuf.alg.model;


import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Gesture {

    private String name;
    private Integer trained;

    /**
     * Convention: Gyroscope.id = 1, Lin_Acc.id = 2, Acc.id = 3
     */
    private List<SensorParam> sensors;

    public Gesture(){
        this.name = "";
        trained = 0;

        this.sensors = new ArrayList<>();

        sensors.add(new SensorParam(Sensor.GYROSCOPE.getId()));
        sensors.add(new SensorParam(Sensor.LINEAR_ACCELERATION.getId()));
        sensors.add(new SensorParam(Sensor.ACCELEROMETER.getId()));
    }

    public Gesture(String name, int classOfGestures){
        this.name = name;
        this.trained = 0;

        this.sensors = new ArrayList<>();

        sensors.add(new SensorParam(Sensor.GYROSCOPE.getId()));
        sensors.add(new SensorParam(Sensor.LINEAR_ACCELERATION.getId()));
        sensors.add(new SensorParam(Sensor.ACCELEROMETER.getId()));
    }

    public Gesture(String name, int classOfGestures, int dominantSensor, List<SensorParam> sensors) {
        this.name = name;
        this.sensors = sensors;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<SensorParam> getSensors() {
        return sensors;
    }

    public void setSensors(List<SensorParam> sensors) {
        this.sensors = sensors;
    }

    public Integer getTrained() {
        return trained;
    }

    public void setTrained(Integer trained) {
        this.trained = trained;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Gesture)) return false;
        Gesture gesture = (Gesture) o;
        return
                Objects.equals(name, gesture.name) &&
                Objects.equals(sensors, gesture.sensors);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, sensors);
    }
}
