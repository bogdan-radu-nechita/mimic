package ino.bogdan.datastuf;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.sensor.AxisInfluencePercentage;
import ino.bogdan.datastuf.alg.training.fileLoading.GestureHolder;
import ino.bogdan.datastuf.configuration.CORSFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DatastufApplication {

	public static void main(String[] args) {
		Gesture g = GestureHolder.getGestures().get(4);

		for(int i = 0; i< g.getSensors().size(); i++){
			for(int j =0; j<g.getSensors().get(i).getSignPercentaceMapping().size(); j++){
				AxisInfluencePercentage axis = g.getSensors().get(i).getSignPercentaceMapping().get(j);
				String sensor = "";
				switch (g.getSensors().get(i).getId()){
					case 1: sensor = "gyroscope"; break;
					case 2: sensor = "lin"; break;
					case 3: sensor = "accelerometer"; break;
				}

				String axisName = "";

				switch (axis.getAxisId()){
					case 1: axisName = "x"; break;
					case 2: axisName = "y"; break;
					case 3: axisName = "z"; break;
				}
				System.out.println("Sensor: " + sensor + " ----- axis: " + axisName + " ------ cell: " + axis.getDominantSign() + " <> " + axis.getDominantPercentage());
			}
		}

		SpringApplication.run(DatastufApplication.class, args);
	}

	@Bean
	public FilterRegistrationBean corsFilterRegistration() {
		FilterRegistrationBean registrationBean =
				new FilterRegistrationBean(new CORSFilter());
		registrationBean.setName("CORS Filter");
		registrationBean.addUrlPatterns("/*");
		registrationBean.setOrder(1);
		return registrationBean;
	}

}
