package ino.bogdan.datastuf.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
@Configuration
@EnableWebSocketMessageBroker
public class WebSockConf extends AbstractWebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/chat/g").setAllowedOrigins("*");
        registry.addEndpoint("/chat/la").setAllowedOrigins("*");
        registry.addEndpoint("/chat/a").setAllowedOrigins("*");
        registry.addEndpoint("/chat/TEST/normal").setAllowedOrigins("*");
        registry.addEndpoint("/chat/TEST/transformed").setAllowedOrigins("*");
        registry.addEndpoint("/dataRecorder/recordGyro").setAllowedOrigins("*");
        registry.addEndpoint("/dataRecorder/recordLinAcc").setAllowedOrigins("*");
        registry.addEndpoint("/dataRecorder/recordAcc").setAllowedOrigins("*");
    }

}
