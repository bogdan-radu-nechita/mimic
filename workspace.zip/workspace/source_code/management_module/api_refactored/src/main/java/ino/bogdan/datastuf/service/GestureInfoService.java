package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.training.fileLoading.GestureHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GestureInfoService {

    public List<String> getAvaialableGestures(){
        HashMap<Integer, Gesture> gestures = GestureHolder.getGestures();
        List<String> result = new ArrayList<>();

        for(Map.Entry<Integer, Gesture> entry : gestures.entrySet()){
            result.add(entry.getValue().getName());
        }

        return result;
    }
}
