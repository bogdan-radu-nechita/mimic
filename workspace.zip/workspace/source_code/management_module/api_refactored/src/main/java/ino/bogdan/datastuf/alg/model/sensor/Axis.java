package ino.bogdan.datastuf.alg.model.sensor;

import java.util.Objects;

public class Axis {
    int id;
    String name;
    Double min;
    Double max;
    Double mean;
    Double quartile; //maybe it should be for the whole sensor?
    public int nrOfValuesParsed;

    public Axis(int id, String name, Double min, Double max, Double mean, Double quartile) {
        this.id = id;
        this.name = name;
        this.min = min;
        this.max = max;
        this.mean = mean;
        this.quartile = quartile;
        this.nrOfValuesParsed = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getMin() {
        return min;
    }

    public void setMin(Double min) {
        this.min = min;
    }

    public Double getMax() {
        return max;
    }

    public void setMax(Double max) {
        this.max = max;
    }

    public Double getMean() {
        return mean;
    }

    public void setMean(Double mean) {
        this.mean = mean;
    }

    public Double getQuartile() {
        return quartile;
    }

    public void setQuartile(Double quartile) {
        this.quartile = quartile;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Axis)) return false;
        Axis axis = (Axis) o;
        return id == axis.id &&
                min == axis.min &&
                max == axis.max &&
                mean == axis.mean &&
                quartile == axis.quartile &&
                Objects.equals(name, axis.name);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, min, max, mean, quartile);
    }
}
