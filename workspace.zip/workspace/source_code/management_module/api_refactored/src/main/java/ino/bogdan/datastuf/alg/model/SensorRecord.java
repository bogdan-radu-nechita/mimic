package ino.bogdan.datastuf.alg.model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.Objects;

@JsonPropertyOrder({"timestamp", "x", "y", "z"})
public class SensorRecord implements Serializable{
    protected Double x;
    protected Double y;
    protected Double z;
    protected Long timestamp;

    public SensorRecord(String[] data) {
        this.x         = Double.parseDouble(data[1]);
        this.y         = Double.parseDouble(data[2]);
        this.z         = Double.parseDouble(data[3]);
        this.timestamp = Long.parseLong(data[0]);
    }

    public SensorRecord(SensorRecord data) {
        this.x         = data.x;
        this.y         = data.y;
        this.z         = data.z;
        this.timestamp = data.timestamp;
    }

    public SensorRecord(Double x, Double y, Double z, Long timestamp) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.timestamp = timestamp;
    }

    public SensorRecord(String timestamp , String x, String y, String z) {
        this.x = Double.parseDouble(x);
        this.y = Double.parseDouble(y);
        this.z = Double.parseDouble(z);
        this.timestamp = Long.parseLong(timestamp);
    }

    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }

    public Double getZ() {
        return z;
    }

    public void setZ(Double z) {
        this.z = z;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SensorRecord acceleration = (SensorRecord) o;
        return Objects.equals(x, acceleration.x) &&
                Objects.equals(y, acceleration.y) &&
                Objects.equals(z, acceleration.z) &&
                Objects.equals(timestamp, acceleration.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y, z, timestamp);
    }

    @Override
    public String toString() {
        return ""+timestamp+","+x+","+y+","+z;
    }
}
