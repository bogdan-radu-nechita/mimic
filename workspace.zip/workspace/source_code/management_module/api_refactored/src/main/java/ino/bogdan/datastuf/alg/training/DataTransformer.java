package ino.bogdan.datastuf.alg.training;


import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.SensorParam;
import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.model.sensor.Axis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataTransformer {
    public static HashMap<Integer, Double> steps;

    public static SensorRecord transformRecordData(SensorParam params, SensorRecord sensorRecord) {
        SensorRecord result = new SensorRecord(sensorRecord);
// HARDOCODEAZA TOT
        /*System.out.println("X"+params.getAxis("x").getMax());
        System.out.println("X"+params.getAxis("x").getMin());
        System.out.println("X"+params.getAxis("x").getMean());
        System.out.println("Y"+params.getAxis("y").getMax());
        System.out.println("Y"+params.getAxis("y").getMin());
        System.out.println("Y"+params.getAxis("y").getMean());
        System.out.println("Z"+params.getAxis("z").getMax());
        System.out.println("Z"+params.getAxis("z").getMin());
        System.out.println("Z"+params.getAxis("z").getMean());*/

        //x

        double distanceFromMean;

        if(params.getAxis("x").getMax() < sensorRecord.getX()) params.getAxis("x").setMax(sensorRecord.getX());
        if(params.getAxis("x").getMin() > sensorRecord.getX()) params.getAxis("x").setMin(sensorRecord.getX());

        if(params.getAxis("x").getMax() == params.getAxis("x").getMin())
            distanceFromMean = 0.0;
        else{
            distanceFromMean = Math.abs((result.getX() - params.getAxis("x").getMean()) * 100 / (params.getAxis("x").getMax() - params.getAxis("x").getMin()));
            if (distanceFromMean < 10) distanceFromMean = 0;
            else if (distanceFromMean < 50)
            {
                distanceFromMean = (result.getX() > params.getAxis("x").getMean() ? 1 : -1);
            }
            else
            {
                distanceFromMean = (result.getX() > params.getAxis("x").getMean() ? 2 : -2);
            }
        }

        result.setX(distanceFromMean);

        //y

        if(params.getAxis("y").getMax() < sensorRecord.getY()) params.getAxis("y").setMax(sensorRecord.getY());
        if(params.getAxis("y").getMin() > sensorRecord.getY()) params.getAxis("y").setMin(sensorRecord.getY());

        if(params.getAxis("y").getMax() == params.getAxis("y").getMin())
            distanceFromMean = 0.0;
        else{
            //-distanceFromMean = Math.abs((result.getY() - params.getAxis("y").getMean()) * 100 / (params.getAxis("y").getMax() - params.getAxis("y").getMin()));
            distanceFromMean = Math.abs((result.getY() - params.getAxis("y").getMean()) * 100 / (75 + 75));
            if (distanceFromMean < 10) distanceFromMean = 0;
            else if (distanceFromMean < 50)
            {
                distanceFromMean = (result.getY() > params.getAxis("y").getMean() ? 1 : -1);
            }
            else
            {
                distanceFromMean = (result.getY() > params.getAxis("y").getMean() ? 2 : -2);
            }
        }

        result.setY(distanceFromMean);

        //z
        if(params.getAxis("z").getMax() < sensorRecord.getZ()) params.getAxis("z").setMax(sensorRecord.getZ());
        if(params.getAxis("z").getMin() > sensorRecord.getZ()) params.getAxis("z").setMin(sensorRecord.getZ());

        if(params.getAxis("z").getMax() == params.getAxis("z").getMin())
            distanceFromMean = 0.0;
        else{
            //distanceFromMean = Math.abs((result.getZ() - params.getAxis("z").getMean()) * 100 / (params.getAxis("z").getMax() - params.getAxis("z").getMin()));
            distanceFromMean = Math.abs((result.getZ() - params.getAxis("z").getMean()) * 100 / (75 + 75));

            if (distanceFromMean < 10) distanceFromMean = 0;
            else if (distanceFromMean < 50)
            {
                distanceFromMean = (result.getZ() > params.getAxis("z").getMean() ? 1 : -1);
            }
            else
            {
                distanceFromMean = (result.getZ() > params.getAxis("z").getMean() ? 2 : -2);
            }
        }

        result.setZ(distanceFromMean);

        return result;
    }

 /*   public static HashMap<Integer, List<SensorRecord>> transforTestFile(DataReader dr, Gesture g) {
        HashMap<Integer, List<SensorRecord>> transformedReadData = new HashMap<>();



        List<Double> transformedX;
        List<Double> transformedY;
        List<Double> transformedZ;


    }*/

    public static List<List<SensorRecord>> transforTestFile(List<List<SensorRecord>> data, Gesture g) {
        List<List<SensorRecord>> transformedReadData = new ArrayList<>();

        /**
         * Gyro
         */
        List<SensorRecord> gyro = new ArrayList<>();
        copySensorRecords(gyro, data.get(0));

        List<Double> axisX = getAllAxisValuesForListOfSensorRecord(gyro, "x");
        axisX = transforAxisData(axisX, g.getSensors().get(0).getAxis("x"));

        List<Double> axisY = getAllAxisValuesForListOfSensorRecord(gyro, "y");
        axisY = transforAxisData(axisY, g.getSensors().get(1).getAxis("y"));

        List<Double> axisZ = getAllAxisValuesForListOfSensorRecord(gyro, "z");
        axisZ = transforAxisData(axisZ, g.getSensors().get(2).getAxis("z"));

        reconstruct(gyro, axisX, axisY, axisZ);

        /**
         * Lin
         */

        List<SensorRecord> lin = new ArrayList<>();
        copySensorRecords(lin, data.get(0));

        axisX = getAllAxisValuesForListOfSensorRecord(lin, "x");
        axisX = transforAxisData(axisX, g.getSensors().get(0).getAxis("x"));

        axisY = getAllAxisValuesForListOfSensorRecord(lin, "y");
        axisY = transforAxisData(axisY, g.getSensors().get(1).getAxis("y"));

        axisZ = getAllAxisValuesForListOfSensorRecord(lin, "z");
        axisZ = transforAxisData(axisZ, g.getSensors().get(2).getAxis("z"));

        reconstruct(lin, axisX, axisY, axisZ);

        /**
         * Acc
         */

        List<SensorRecord> acc = new ArrayList<>();
        copySensorRecords(acc, data.get(0));

        axisX = getAllAxisValuesForListOfSensorRecord(acc, "x");
        axisX = transforAxisData(axisX, g.getSensors().get(0).getAxis("x"));

        axisY = getAllAxisValuesForListOfSensorRecord(acc, "y");
        axisY = transforAxisData(axisY, g.getSensors().get(1).getAxis("y"));

        axisZ = getAllAxisValuesForListOfSensorRecord(acc, "z");
        axisZ = transforAxisData(axisZ, g.getSensors().get(2).getAxis("z"));

        reconstruct(acc, axisX, axisY, axisZ);

        /**
         * rebuild and return
         */
        transformedReadData.add(gyro);
        transformedReadData.add(lin);
        transformedReadData.add(acc);

        return transformedReadData;
    }

    public static void reconstruct(List<SensorRecord> data, List<Double> axisX, List<Double> axisY, List<Double> axisZ){
        for(int i = 0; i< data.size(); i++ ){
            data.get(i).setX(axisX.get(i));
            data.get(i).setY(axisY.get(i));
            data.get(i).setZ(axisZ.get(i));
        }
    }

    public static void copySensorRecords(List<SensorRecord> empty, List<SensorRecord> data){
        for(SensorRecord s: data){
            empty.add(s);
        }
    }

    public static List<Double> getAllAxisValuesForListOfSensorRecord(List<SensorRecord> data, String axis){
        List<Double> result = new ArrayList<>();

        for(SensorRecord s : data){
            switch (axis){
                case "x": result.add(s.getY()); break;
                case "y": result.add(s.getY()); break;
                case "z": result.add(s.getY()); break;
            }

        }

        return result;
    }

    public static List<Double> transforAxisData(List<Double> axisValues, Axis axis) {
        double mean = 0.0;

        List<Double> transformedAxisValues = new ArrayList<>();

        for (int i = 0; i < axisValues.size(); i++){

            mean = mean * axisValues.size();
            mean = (mean + axisValues.get(i)) / axisValues.size();

            if(axisValues.get(i) > axis.getMax()){
                axis.setMax(axisValues.get(i));
            }

            if(axisValues.get(i) < axis.getMin()){
                axis.setMin(axisValues.get(i));
            }

            double distanceFromMean;

            if(axis.getMax() == axis.getMin())
                distanceFromMean = 0.0;
            else{
                distanceFromMean = Math.abs((axisValues.get(i) - mean) * 100 / (axis.getMax() - axis.getMin()));
                if (distanceFromMean < 10) distanceFromMean = 0;
                else if (distanceFromMean < 50)
                {
                    distanceFromMean = (axisValues.get(i) > mean ? 1 : -1);
                }
                else
                {
                    distanceFromMean = (axisValues.get(i) > mean ? 2 : -2);
                }
            }

            transformedAxisValues.add(distanceFromMean);

        }

        return transformedAxisValues;
    }
}
