package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.model.sensor.AxisInfluencePercentage;
import ino.bogdan.datastuf.alg.training.fileLoading.GestureHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ino.bogdan.datastuf.alg.training.fileLoading.GestureHolder.getGestures;

@Service
public class DataAnalysisService {
    public static boolean record = false;
    public static int start = 0;
    public static int end = 0;

    public static void checkSignalForGestures(int numberOf0sG_old, int index){
        //System.out.println("analyzing: " + numberOf0sG_old + " " + index);
        if(record == false){
            if(RecordHolder.numberOf0sG > 10 && numberOf0sG_old == RecordHolder.numberOf0sG){
                System.out.println("starting: " + numberOf0sG_old + " " + index);
                RecordHolder.numberOf0sG = 0;
                start = index;
                record = true;
            }
        }else{
            if(RecordHolder.numberOf0sG > 6 && numberOf0sG_old < RecordHolder.numberOf0sG){
                System.out.println("stopping: " + numberOf0sG_old + " " + index);
                end = index;
                record = false;
                System.out.println(checkForGesture());
            }
        }
    }

    //public static void checkSignalForGestureStop(int numberOf0sG_old, int index)
    public static String checkForGesture(){
        String result = "";

        List<SensorRecord> dataG = new ArrayList<>();
        List<SensorRecord> dataL = new ArrayList<>();
        List<SensorRecord> dataA = new ArrayList<>();

            System.out.println("Checking for sign");
            //summarizeSensor
            //checkAgainstOtherGestures
            // return result
        AxisInfluencePercentage axisInflX = new AxisInfluencePercentage(0);
        AxisInfluencePercentage axisInflY = new AxisInfluencePercentage(1);
        AxisInfluencePercentage axisInflZ = new AxisInfluencePercentage(2);

        List<Double> axX = new ArrayList<>();
        List<Double> axY = new ArrayList<>();
        List<Double> axZ = new ArrayList<>();

        /**
         * add a for loop so that you treat for each sensor
         */

        /**
         * copy all data
         */
        for(int i = start; i < end; i++){
            dataG.add(RecordHolder.gyroscopeData.get(i));
            //dataL.add(RecordHolder.linData.get(i));
            //pt acc trebuie shiftat, cauta sa te uiti dupa timestamp, nu index, sau un index suplimentar
        }

        axX = getAxisValues("x", dataG);
        String signX = summarizeAxis("x", axX, 25.0);

        axY = getAxisValues("y", dataG);
        String signY = summarizeAxis("y", axY, 25.0);

        axZ = getAxisValues("z", dataG);
        String signZ = summarizeAxis("z", axZ, 25.0);



        return compareWithTrainedData(signX,signY,signZ);
    }

    public static String compareWithTrainedData(String signX, String signY, String signZ){
        String result = "";
        int winningGesture = 0;
        int maxScore = 0;
        int score = 0;

        for(Map.Entry<Integer, Gesture> gesture : GestureHolder.getGestures().entrySet()){
            score = 0;
            /*if(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(0).getDominantSign().contains(signX)){
                score++;
            }

            if(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(1).getDominantSign().contains(signY)){
                score++;
            }

            if(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(2).getDominantSign().contains(signZ)){
                score++;
            }*/

            if(signX.contains(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(0).getDominantSign())){
                score++;
            }
            if(signY.contains(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(1).getDominantSign())){
                score++;
            }
            if(signZ.contains(gesture.getValue().getSensors().get(0).getSignPercentaceMapping().get(2).getDominantSign())){
                score++;
            }

            if(maxScore < score){
                winningGesture = gesture.getKey();
                maxScore = score;
            }
        }

        try{
            result = GestureHolder.getGestures().get(winningGesture).getName();
        }catch(NullPointerException e){
            e.printStackTrace();
            result = "Unrecognizable gesture";
        }

        return result;
    }

    private static double[] initLocalParams(List<Double> axisValues){
        double max = 0;
        double min = 0;
        double mean = 0;

        if(axisValues.size() > 0){
            max = axisValues.get(0);
            min = axisValues.get(0);
            mean = axisValues.get(0)/axisValues.size();

            for(Double value : axisValues){
                if (min > value) min = value;
                if (max < value) max = value;
                mean += value / axisValues.size();
            }
        }

        return new double[]{min, max, mean};
    }

    static List<Double> getAxisValues(String axis, List<SensorRecord> fileRecords){
        List<Double> result = new ArrayList<>();

        for(int i=0; i<fileRecords.size(); i++){
            switch (axis){
                case "x": result.add(fileRecords.get(i).getX()); break;
                case "y": result.add(fileRecords.get(i).getY()); break;
                case "z": result.add(fileRecords.get(i).getZ()); break;
            }
        }

        return result;
    }

    private  static String summarizeAxis(String axis, List<Double> axisValues, Double percentage){
        String result = "";
        double[] localParams = initLocalParams(axisValues);

        double localMin = localParams[0];
        double localMax = localParams[1];
        double localMean = localParams[2];

        for(double value : axisValues){
            int heigth = Math.abs((value - localMean) * 100 / (localMax - localMin)) < percentage ? 0:(value > localMean?1:-1);

            if (heigth > 0) {
                if (result == "")
                    result = "+";
                else
                if (result.charAt(result.length()-1) != '+')
                    result += "+";
            }
            else if (heigth < 0)
            {
                if (result == "")
                    result = "-";
                else
                if (result.charAt(result.length()-1) != '-')
                    result += "-";
            }
        }

        return result;
    }

    public static void handleSign(String sign, String axis, HashMap<String, Double> signCollection){

        if(signCollection.containsKey(sign)){
            signCollection.put(sign, signCollection.get(sign) + 1.0);
        } else{
            signCollection.put(sign, 1.0);
        }

    }
}
