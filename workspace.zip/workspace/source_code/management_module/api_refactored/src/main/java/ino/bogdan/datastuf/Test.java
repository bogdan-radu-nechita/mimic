package ino.bogdan.datastuf;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.util.StringUtils;

import java.io.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;


public class Test {

    public static String[] parseLine(String line){
        return StringUtils.tokenizeToStringArray("1529411036845,-1.6271194219589233,-2.65842604637146,9.93978500366211", ",");
    }

    public static void main(String[] args){
        System.out.println(-3.812601789832115E-7);
        BigDecimal d = new BigDecimal(-3.812601789832115E-7);
        //0.999999618739821

        HashMap<Integer, List<SensorRecord>> storedGyroData = new HashMap<>();;

        String line;
        BufferedReader in = null;
        int i = 0;

        File folder = new File(Constants.RAW_GATHERED_DATA_DIR + Sensor.GYROSCOPE.getFolder());
        File[] listOfFiles = folder.listFiles();

        /*for (File file : listOfFiles) {
            if (file.isFile()) {
                System.out.println(file.getName());
            }
        }*/

        for (File file : listOfFiles) {
            if (file.getName().equals("gyro_1.txt")) {
                System.out.println("YOLO");
            }
        }
    }
}
