package ino.bogdan.datastuf.alg.training;


import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.model.SensorParam;
import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.model.sensor.Axis;
import ino.bogdan.datastuf.alg.training.fileLoading.DataReader;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.model.infoholders.Sensor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class GestureTrainer {
    Gesture gesture;
    HashMap<Integer, Double> signPercentageMapping;
    static int numberOfXs, numberOfYs, numberOfZs;

    public GestureTrainer(Gesture gesture){
        this.gesture = gesture;
    }

    public void train(){
        System.out.println("[Trainer] Loading gesture - " + gesture.getName() + " - raw training data...");
        DataReader dr = new DataReader(gesture.getName());
        System.out.println("[Trainer] Loading complete.");

        System.out.println("[Trainer] Training...");
        summarizeASensor(Sensor.GYROSCOPE.getId(), dr.allTrainingData.get(Sensor.GYROSCOPE.getId()));
        summarizeASensor(Sensor.LINEAR_ACCELERATION.getId(), dr.allTrainingData.get(Sensor.LINEAR_ACCELERATION.getId()));
        summarizeASensor(Sensor.ACCELEROMETER.getId(), dr.allTrainingData.get(Sensor.ACCELEROMETER.getId()));

        gesture.setTrained(1);
        System.out.println("[Trainer] " + gesture.getName() + " - training complete!");
        //System.out.println("[Trainer] ");

        for(int i=0;i<gesture.getSensors().size(); i++){
            SensorParam s = gesture.getSensors().get(i);

            for(int j=0; j< s.getAxis().size(); j++){
                Axis axis = s.getAxis().get(j);
                //axis.setMean(0.0);
                axis.setMax(100.0);
                axis.setMin(-100.0);
            }
        }
    }

    /**
     * Puts out the global mean, max, min, quartile and sign mapping
     * @param sensorData
     * @return
     */
    private void summarizeASensor(int sensor, List<List<SensorRecord>> sensorData) {
        List<Double> axisValues = new ArrayList<>();
        numberOfXs = 0; numberOfYs = 0; numberOfZs = 0;
        /**
         * For each file
         */
        for (int i = 0; i < sensorData.size(); i++) {

            /**
             * get all values for an axis
             */
            axisValues = getAxisValues("x", sensorData.get(i));
            numberOfXs += axisValues.size();
            /**
             * get the sign for an axis of a file
             */
            String sign = summarizeAxisOfAFile(sensor, "x", axisValues, 25.0);
            /**
             * see if the sign was already found and form
             */
            handleSign(sign, "x", this.gesture.getSensors().get(sensor - 1).getSignPercentaceMapping().get(0).getSignPercentages());

            axisValues = getAxisValues("y", sensorData.get(i));
            numberOfYs += axisValues.size();
            sign = summarizeAxisOfAFile(sensor, "y", axisValues, 25.0);
            handleSign(sign, "y", this.gesture.getSensors().get(sensor - 1).getSignPercentaceMapping().get(1).getSignPercentages());

            axisValues = getAxisValues("z", sensorData.get(i));
            numberOfXs += axisValues.size();
            sign = summarizeAxisOfAFile(sensor, "z", axisValues, 25.0);
            handleSign(sign, "z", this.gesture.getSensors().get(sensor - 1).getSignPercentaceMapping().get(2).getSignPercentages());

        }

        /*double currentGlobalMean = gesture.getSensors().get(sensor-1).getAxis("x").getMean();
        gesture.getSensors().get(sensor-1).getAxis("x").setMean(currentGlobalMean/numberOfXs);

        currentGlobalMean = gesture.getSensors().get(sensor-1).getAxis("y").getMean();
        gesture.getSensors().get(sensor-1).getAxis("y").setMean(currentGlobalMean/numberOfYs);

        currentGlobalMean = gesture.getSensors().get(sensor-1).getAxis("z").getMean();
        gesture.getSensors().get(sensor-1).getAxis("z").setMean(currentGlobalMean/numberOfYs);*/

    }

    /**
     * Add code to update the SensorParam here to find mean, max, min
     * @param axisValues
     * @param percentage
     * @return
     */
    private String summarizeAxisOfAFile(int sensor, String axis, List<Double> axisValues, Double percentage){
        String result = "";
        double[] localParams = initLocalParams(axisValues);

        double localMin = localParams[0];
        double localMax = localParams[1];
        double localMean = localParams[2];

        if(localMax > gesture.getSensors().get(sensor-1).getAxis(axis).getMax())
            gesture.getSensors().get(sensor-1).getAxis(axis).setMax(localMax);

        if(localMin < gesture.getSensors().get(sensor-1).getAxis(axis).getMin())
            gesture.getSensors().get(sensor-1).getAxis(axis).setMin(localMin);


        gesture.getSensors().get(sensor-1).getAxis(axis).setMean(localMean);

        for(double value : axisValues){
            double currentGlobalMean = gesture.getSensors().get(sensor-1).getAxis(axis).getMean();
            gesture.getSensors().get(sensor-1).getAxis(axis).setMean(currentGlobalMean + value);
            int heigth = Math.abs((value - localMean) * 100 / (localMax - localMin)) < percentage ? 0:(value > localMean?1:-1);

            if (heigth > 0) {
                if (result == "")
                    result = "+";
                else
                    if (result.charAt(result.length()-1) != '+')
                        result += "+";
            }
            else if (heigth < 0)
            {
                if (result == "")
                    result = "-";
                else
                if (result.charAt(result.length()-1) != '-')
                    result += "-";
            }
        }

        return result;
    }

    public void handleSign(String sign, String axis, HashMap<String, Double> signCollection){

        if(signCollection.containsKey(sign)){
            signCollection.put(sign, signCollection.get(sign) + 1.0);
        } else{
            signCollection.put(sign, 1.0);
        }

    }

    List<Double> getAxisValues(String axis, List<SensorRecord> fileRecords){
        List<Double> result = new ArrayList<>();

        for(int i=0; i<fileRecords.size(); i++){
            switch (axis){
                case "x": result.add(fileRecords.get(i).getX()); break;
                case "y": result.add(fileRecords.get(i).getY()); break;
                case "z": result.add(fileRecords.get(i).getZ()); break;
            }
        }

        return result;
    }

    private double[] initLocalParams(List<Double> axisValues){
        double max = 0;
        double min = 0;
        double mean = 0;

        if(axisValues.size() > 0){
            max = axisValues.get(0);
            min = axisValues.get(0);
            mean = axisValues.get(0)/axisValues.size();

            for(Double value : axisValues){
                if (min > value) min = value;
                if (max < value) max = value;
                mean += value / axisValues.size();
            }
        }

        return new double[]{min, max, mean};
    }


}
