package ino.bogdan.datastuf.alg;


import ino.bogdan.datastuf.alg.model.Gesture;
import ino.bogdan.datastuf.alg.training.GestureTrainer;
import ino.bogdan.datastuf.alg.utils.Constants;

import java.util.HashMap;
import java.util.Map;

public class PH {
    public static void main(String[] args){
        // Open = 1, Slap = 2, Grab = 3
        HashMap<Integer, Gesture> gestures = new HashMap<>();

        gestures.put(1, new Gesture("open", Constants.UNKNOWN));
        gestures.put(2, new Gesture("slap", Constants.FORWARD));
        gestures.put(3, new Gesture("grab", Constants.FORWARD));

        //DataReader dr = new DataReader("open");
        //System.out.println(dr.allTrainingData.get(1).size() + " " + dr.allTrainingData.get(2).size() + " " + dr.allTrainingData.get(3).size());

        GestureTrainer openGT = new GestureTrainer(gestures.get(1));
        openGT.train();                                    //iti da un sensorParam -> afisam pt fiecare axa

        GestureTrainer slapGT = new GestureTrainer(gestures.get(2));
        slapGT.train();                                    //iti da un sensorParam -> afisam pt fiecare axa

        for(Map.Entry entry : gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(0).getSignPercentages().entrySet()){
            System.out.println("Key: " + entry.getKey() + " ---- " + "Value: " + entry.getValue());
        }
        System.out.println("");

        System.out.println("");System.out.println("The most useful is");
        System.out.println(gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(0).getDominantSign() + " -> " + gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(0).getDominantPercentage());
        System.out.println(gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(1).getDominantSign() + " -> " + gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(1).getDominantPercentage());
        System.out.println(gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(2).getDominantSign() + " -> " + gestures.get(2).getSensors().get(0).getSignPercentaceMapping().get(2).getDominantPercentage());
    }
}



/*for(Map.Entry entry : gestures.get(1).getSensors().get(0).getSignPercentaceMapping().get(0).getSignPercentages().entrySet()){
            System.out.println("Key: " + entry.getKey() + " ---- " + "Value: " + entry.getValue());
        }
        System.out.println("");
        for(Map.Entry entry : gestures.get(1).getSensors().get(0).getSignPercentaceMapping().get(1).getSignPercentages().entrySet()){
            System.out.println("Key: " + entry.getKey() + " ---- " + "Value: " + entry.getValue());
        }
        System.out.println("");
        for(Map.Entry entry : gestures.get(1).getSensors().get(0).getSignPercentaceMapping().get(2).getSignPercentages().entrySet()){
            System.out.println("Key: " + entry.getKey() + " ---- " + "Value: " + entry.getValue());
        }

        System.out.println("");System.out.println("The most useful is");
        System.out.println(gestures.get(1).getSensors().get(0).getSignPercentaceMapping().get(0).getDominantSign() + " -> " + gestures.get(1).getSensors().get(0).getSignPercentaceMapping().get(0).getDominantPercentage());*/