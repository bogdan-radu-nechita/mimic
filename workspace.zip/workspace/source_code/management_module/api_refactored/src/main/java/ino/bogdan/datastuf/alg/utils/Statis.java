package ino.bogdan.datastuf.alg.utils;

import java.util.HashMap;

public class Statis {
    public static HashMap<Integer, Double> steps;
}
