package ino.bogdan.datastuf.configuration;

import ino.bogdan.datastuf.model.infoholders.Gestures;
import org.springframework.stereotype.Component;

@Component
public class AppStats {
    public static Gestures gesture;
    public static int files;
    public static boolean firstTime = true;
}
