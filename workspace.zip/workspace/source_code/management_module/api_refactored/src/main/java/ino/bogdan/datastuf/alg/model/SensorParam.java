package ino.bogdan.datastuf.alg.model;

import ino.bogdan.datastuf.alg.model.sensor.Axis;
import ino.bogdan.datastuf.alg.model.sensor.AxisInfluencePercentage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class SensorParam {
    int id;
    List<Axis> axis;
    List<AxisInfluencePercentage> axisSigns;

    public SensorParam(int id){

        this.id = id;

        /**
         * axisX.id = 1;
         * axisY.id = 2;
         * axisZ.id = 3;
         */
        axis = new ArrayList<>();
        axis.add(new Axis(1, "axisX", 0.0,0.0, 0.0, 0.0));
        axis.add(new Axis(2, "axisY", 0.0,0.0, 0.0, 0.0));
        axis.add(new Axis(3, "axisZ", 0.0,0.0, 0.0, 0.0));

        axisSigns = new ArrayList<>();

        axisSigns.add(new AxisInfluencePercentage(1));
        axisSigns.add(new AxisInfluencePercentage(2));
        axisSigns.add(new AxisInfluencePercentage(3));
    }

    public SensorParam(int id, List<Axis> axis, List<AxisInfluencePercentage>signPercentaceMapping) {
        this.id = id;
        this.axis = axis;
        this.axisSigns = signPercentaceMapping;
    }

    public List<Axis> getAxis() {
        return axis;
    }

    public Axis getAxis(String axisName) {
        switch (axisName){
            case "x": return this.axis.get(0);
            case "y": return this.axis.get(1);
            case "z": return this.axis.get(2);
        }
        return null;
    }

    public void setAxis(List<Axis> axis) {
        this.axis = axis;
    }

    public List<AxisInfluencePercentage> getSignPercentaceMapping() {
        return axisSigns;
    }

    public void setSignPercentaceMapping(List<AxisInfluencePercentage> signPercentaceMapping) {
        this.axisSigns = signPercentaceMapping;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<AxisInfluencePercentage> getAxisSigns() {
        return axisSigns;
    }

    public void setAxisSigns(List<AxisInfluencePercentage> axisSigns) {
        this.axisSigns = axisSigns;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SensorParam)) return false;
        SensorParam that = (SensorParam) o;
        return Objects.equals(axis, that.axis) &&
                Objects.equals(axisSigns, that.axisSigns);
    }

    @Override
    public int hashCode() {

        return Objects.hash(axis, axisSigns);
    }
}
