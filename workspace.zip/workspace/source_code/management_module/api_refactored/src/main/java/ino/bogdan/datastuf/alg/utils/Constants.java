package ino.bogdan.datastuf.alg.utils;

public class Constants {
    public static final int UNKNOWN = 0;
    public static final int FORWARD = 1;

    public static final int GYROSCOPE_KEY = 1;
    public static final int LIN_ACC_KEY = 2;
    public static final int ACCELEROMETER_KEY = 3;

    // TODO: instead of files, use a db
    public static String DATA_DIR                = "data_sets/a";
    public static String TRAINING_DATA_DIR       = "data_sets/training_data";
    public static String RAW_GATHERED_DATA_DIR   = "data_sets/a/raw";
    public static String TRIMMED_DATA_DIR        = "data_sets/a/trimmed";

    public static String FILE_TYPE = ".txt";
}
