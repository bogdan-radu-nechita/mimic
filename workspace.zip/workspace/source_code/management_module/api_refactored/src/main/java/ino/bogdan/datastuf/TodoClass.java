package ino.bogdan.datastuf;

public class TodoClass {
    //TODO: put everything in a mongoDB? -> in case you need to filter by timestamp or something like that
    //TODO: register data using milliseconds/nano
    //TODO: find a way to plot it

    //
}
