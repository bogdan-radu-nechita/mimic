package ino.bogdan.datastuf.service;

import ino.bogdan.datastuf.alg.model.SensorRecord;
import ino.bogdan.datastuf.alg.utils.Constants;
import ino.bogdan.datastuf.configuration.AppStats;
import ino.bogdan.datastuf.model.infoholders.Sensor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

@Service
public class FileHandler {

    private ClassLoader classLoader = FileHandler.class.getClassLoader();

    public String[] parseLine(String line){
        return StringUtils.tokenizeToStringArray(line, ",");
    }

    public HashMap<Integer, HashMap> loadData(){
        HashMap<Integer, HashMap> allData = new HashMap<>();

        allData.put(Sensor.GYROSCOPE.getId(),           loadSensorData(Sensor.GYROSCOPE));
        allData.put(Sensor.LINEAR_ACCELERATION.getId(), loadSensorData(Sensor.LINEAR_ACCELERATION));
        allData.put(Sensor.ACCELEROMETER.getId(),       loadSensorData(Sensor.ACCELEROMETER));

        return allData;
    }

    /**
     * TODO: Do it with streams and paths, not file
     */
    public HashMap<Integer, List<SensorRecord>> loadSensorData(Sensor sensor){
        String line;
        BufferedReader in;
        int i = 0;
        HashMap<Integer, List<SensorRecord>> recordMap = new HashMap<>();

        File folder = new File(classLoader.getResource(Constants.TRAINING_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile());
        File[] listOfFiles = folder.listFiles();

        for (File file : listOfFiles) {
            try {
                in = new BufferedReader(new FileReader(file));
                recordMap.put(++i, new ArrayList<>());

                if (file.isFile()) {
                    while((line = in.readLine()) != null){

                        String[] data = parseLine(line);
                        recordMap.get(i).add(new SensorRecord(data));

                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            }

        }

        return recordMap;
    }

    public int getFileNumber(){
        // https://howtodoinjava.com/java/io/read-file-from-resources-folder/
        System.out.println("Class Loader " + classLoader);
        System.out.println("Class Loader " + Constants.RAW_GATHERED_DATA_DIR);
        System.out.println("Class Loader " + AppStats.gesture.getFolder());
        System.out.println("Class Loader " + Sensor.GYROSCOPE.getFolder());
        System.out.println("Class Loader " + Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder());
        System.out.println("Class Loader " + Constants.TRAINING_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder());
        System.out.println("Class Loader interest " + classLoader.getResource(Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder()));
        System.out.println("Class Loader interest " + classLoader.getResource("data_sets/a"));
        System.out.println("Class Loader " + classLoader.getResource("data_sets"));
        System.out.println("Class Loader " + classLoader.getResource(Constants.TRAINING_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder()));
//Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder()).getFile()
        File folder = new File(classLoader.getResource(Constants.TRAINING_DATA_DIR + AppStats.gesture.getFolder() + Sensor.GYROSCOPE.getFolder()).getFile()); //The number of files should be the same for each sensor of a sign
        File[] listOfFiles = folder.listFiles();

        return listOfFiles.length;
    }

    public HashMap<Integer, List> getFileByNumber(int fileNumber){
        HashMap<Integer, List> result = new HashMap<>();

        result.put(Sensor.GYROSCOPE.getId(),getSensorFileByNumber(Sensor.GYROSCOPE, fileNumber));
        result.put(Sensor.LINEAR_ACCELERATION.getId(),getSensorFileByNumber(Sensor.LINEAR_ACCELERATION, fileNumber));
        result.put(Sensor.ACCELEROMETER.getId(),getSensorFileByNumber(Sensor.ACCELEROMETER, fileNumber));

        return result;
    }

    public List<SensorRecord> getSensorFileByNumber(Sensor sensor,int fileNumber){
        List<SensorRecord> result = new ArrayList<>();
        String line;
        BufferedReader in;

        // TODO: REVIEW
        File folder = new File(classLoader.getResource(Constants.TRAINING_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile());
        File[] listOfFiles = folder.listFiles();

        for (File file : listOfFiles) {
            if (file.getName().equals(sensor.getFilePrefix() + fileNumber + Constants.FILE_TYPE)) {
                try {
                    in = new BufferedReader(new FileReader(file));
                    while((line = in.readLine()) != null){

                        String[] data = parseLine(line);
                        result.add(new SensorRecord(data));

                    }
                    in.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }

        return result;
    }

    public void reduceSensorDataSetToGesture(Sensor sensor, int fileNumber, long min, long max){
        List<SensorRecord> result = new ArrayList<>();
        String line;
        BufferedReader in = null;

        File folder = new File(classLoader.getResource(Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile());
        File[] listOfFiles = folder.listFiles();

        for (File file : listOfFiles){
            if(file.getName().equals(sensor.getFilePrefix() + fileNumber + Constants.FILE_TYPE)){
                try {
                    in = new BufferedReader(new FileReader(file));
                    while((line = in.readLine()) != null){

                        String[] data = parseLine(line);
                        long timestamp = Long.parseLong(data[0]);

                        if(timestamp > min && timestamp < max){
                            result.add(new SensorRecord(data));
                        }
                    }
                    in.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }

        String fContent = buildSbSensorRecord(result);
        saveToFile(sensor, fContent);
    }

    public void saveToFile(Sensor sensor, String fileContent){
        long numberOfFiles = 0;

        // use try-with-resource
        try (Stream<Path> paths = Files.walk(Paths.get(classLoader.getResource(Constants.TRIMMED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile()))) {
            numberOfFiles = paths.count() - 1; //paths.count returns 1 if there are no files present
        }catch(IOException e){
            e.printStackTrace();
        }

        String fileName = sensor.getFilePrefix() + ++numberOfFiles + Constants.FILE_TYPE;

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(classLoader.getResource(Constants.TRIMMED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder() + fileName).getFile());
            out.write(fileContent.getBytes());
            out.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public String buildSbSensorRecord(List<SensorRecord> srs){
        StringBuilder sb = new StringBuilder();

        for(SensorRecord sr: srs){
            try{sb.append(sr.toString());} catch(NullPointerException e){System.out.println("am dat peste npe sr");}
            sb.append("\n");
        }

        return sb.toString();
    }

    public void deleteLastFile(){

        for (Sensor sensor : Sensor.values()){
            File folder = new File(classLoader.getResource(Constants.RAW_GATHERED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile());
            File[] listOfFiles = folder.listFiles();

            for (File file : listOfFiles) {
                if (file.getName().equals(sensor.getFilePrefix() + listOfFiles.length + Constants.FILE_TYPE)) {
                    file.delete();
                }
            }
        }

        System.out.println("deleted....");
    }

    public void deleteLastTrimmedFile(){
        for (Sensor sensor : Sensor.values()){
            File folder = new File(classLoader.getResource(Constants.TRIMMED_DATA_DIR + AppStats.gesture.getFolder() + sensor.getFolder()).getFile());
            File[] listOfFiles = folder.listFiles();

            for (File file : listOfFiles) {
                if (file.getName().equals(sensor.getFilePrefix() + listOfFiles.length + Constants.FILE_TYPE)) {
                    file.delete();
                }
            }
        }

        System.out.println("deleted....");
    }

}
