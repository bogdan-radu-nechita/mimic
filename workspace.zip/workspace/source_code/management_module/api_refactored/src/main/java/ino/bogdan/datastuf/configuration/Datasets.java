package ino.bogdan.datastuf.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = "classpath:settings/datasets.properties")
public class Datasets {
    @Value("${datasets.directory}")
    private String datasetsDirectory;

    public String getDatasetsDirectory() {
        return datasetsDirectory;
    }

    public void setDatasetsDirectory(String datasetsDirectory) {
        this.datasetsDirectory = datasetsDirectory;
    }
}
